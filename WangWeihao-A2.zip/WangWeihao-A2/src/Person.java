public abstract class Person {
    // Private fields to store the name of the person
    private String name;
    // Private field to store the age of the person
    private int age;
    // Private field to store the gender of the person
    private String gender;
    // Private field to store the contact number of the person
    private String contactNumber;

    // Default constructor for the Person class
    public Person() {
        // Initializes a new instance of the Person class with default values
    }

    // Parameterized constructor for the Person class
    public Person(String name, int age, String gender, String contactNumber) {
        // Assigns the provided name to the name field
        this.name = name;
        // Assigns the provided age to the age field
        this.age = age;
        // Assigns the provided gender to the gender field
        this.gender = gender;
        // Assigns the provided contact number to the contactNumber field
        this.contactNumber = contactNumber;
    }

    // Getter method for the name field
    public String getName() {
        // Returns the name of the person
        return name;
    }

    // Setter method for the name field
    public void setName(String name) {
        // Sets the name of the person to the provided value
        this.name = name;
    }

    // Getter method for the age field
    public int getAge() {
        // Returns the age of the person
        return age;
    }

    // Setter method for the age field
    public void setAge(int age) {
        // Sets the age of the person to the provided value
        this.age = age;
    }

    // Getter method for the gender field
    public String getGender() {
        // Returns the gender of the person
        return gender;
    }

    // Setter method for the gender field
    public void setGender(String gender) {
        // Sets the gender of the person to the provided value
        this.gender = gender;
    }

    // Getter method for the contactNumber field
    public String getContactNumber() {
        // Returns the contact number of the person
        return contactNumber;
    }

    // Setter method for the contactNumber field
    public void setContactNumber(String contactNumber) {
        // Sets the contact number of the person to the provided value
        this.contactNumber = contactNumber;
    }
}