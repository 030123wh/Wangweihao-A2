public class Employee extends Person {
    // Private field to store the employee's ID
    private String employeeId;
    // Private field to store the department of the employee
    private String department;
    // Private field to store the salary of the employee
    private double salary;
    // Boolean field to indicate if the employee is currently on duty
    boolean isOnDuty;

    // Default constructor for the Employee class
    public Employee() {
        // Initializes a new instance of the Employee class with default values
    }

    // Parameterized constructor for the Employee class
    public Employee(String name, int age, String gender, String contactNumber,
                    String employeeId, String department, double salary) {
        // Calls the constructor of the superclass Person to initialize inherited fields
        super(name, age, gender, contactNumber);
        // Assigns the provided employee ID to the employeeId field
        this.employeeId = employeeId;
        // Assigns the provided department to the department field
        this.department = department;
        // Assigns the provided salary to the salary field
        this.salary = salary;
        // Sets the isOnDuty field to false, indicating the employee is not on duty initially
        this.isOnDuty = false;
    }

    // Method to start the employee's shift
    public void startShift() {
        // Sets the isOnDuty field to true, indicating the employee is now on duty
        this.isOnDuty = true;
    }

    // Method to end the employee's shift
    public void endShift() {
        // Sets the isOnDuty field to false, indicating the employee is no longer on duty
        this.isOnDuty = false;
    }

    // Method to check if the employee is on duty
    public boolean isOnDuty() {
        // Returns false, but this seems incorrect; should return the value of isOnDuty
        return false;
    }
}