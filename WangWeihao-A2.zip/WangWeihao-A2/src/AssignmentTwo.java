public class AssignmentTwo {
    public static void main(String[] args) {
        // Create an instance of AssignmentTwo
        AssignmentTwo assignment = new AssignmentTwo();

        // The following method calls are commented out and won't be executed
        // Uncomment them to execute
        // assignment.partThree();
        // assignment.partFourA();
        // assignment.partFourB();
        // assignment.partFive();

        // Execute partSix method
        assignment.partSix();

        // Execute partSeven method
        assignment.partSeven();
    }

    public void partThree() {
        // Create a new Ride object named "rollerCoaster"
        // with a maximum capacity of 30, minimum height of 140 cm, and price of 50.0
        Ride rollerCoaster = new Ride("过山车", 30, 140, 50.0);

        // Create at least 5 Visitor objects with different attributes
        Visitor v1 = new Visitor("张三", 25, "男", "13800138000", "V001", false, 200.0);
        Visitor v2 = new Visitor("李四", 30, "女", "13900139000", "V002", true, 300.0);
        Visitor v3 = new Visitor("王五", 22, "男", "13700137000", "V003", false, 150.0);
        Visitor v4 = new Visitor("赵六", 28, "女", "13600136000", "V004", true, 250.0);
        Visitor v5 = new Visitor("钱七", 35, "男", "13500135000", "V005", false, 180.0);

        // Add visitors to the ride's queue
        System.out.println("添加访客到队列：");
        rollerCoaster.addVisitorToQueue(v1);
        rollerCoaster.addVisitorToQueue(v2);
        rollerCoaster.addVisitorToQueue(v3);
        rollerCoaster.addVisitorToQueue(v4);
        rollerCoaster.addVisitorToQueue(v5);

        // Print the initial state of the queue
        System.out.println("\n初始队列状态：");
        rollerCoaster.printQueue();

        // Remove one visitor from the queue
        System.out.println("\n移除一个访客：");
        rollerCoaster.removeVisitorFromQueue();

        // Print the state of the queue after removal
        System.out.println("\n移除后的队列状态：");
        rollerCoaster.printQueue();
    }

    public void partFourA() {
        // Part to be implemented in subsequent tasks
        // Create a new Ride object named "ferrisWheel"
        // with a maximum capacity of 20, minimum height of 100 cm, and price of 30.0
        Ride ferrisWheel = new Ride("摩天轮", 20, 100, 30.0);

        // Create at least 5 Visitor objects with different attributes
        Visitor v1 = new Visitor("张三", 25, "男", "13800138000", "V001", false, 200.0);
        Visitor v2 = new Visitor("李四", 30, "女", "13900139000", "V002", true, 300.0);
        Visitor v3 = new Visitor("王五", 22, "男", "13700137000", "V003", false, 150.0);
        Visitor v4 = new Visitor("赵六", 28, "女", "13600136000", "V004", true, 250.0);
        Visitor v5 = new Visitor("钱七", 35, "男", "13500135000", "V005", false, 180.0);

        // Add visitors to the ride's history
        System.out.println("添加访客到乘坐历史记录：");
        ferrisWheel.addVisitorToHistory(v1);
        ferrisWheel.addVisitorToHistory(v2);
        ferrisWheel.addVisitorToHistory(v3);
        ferrisWheel.addVisitorToHistory(v4);
        ferrisWheel.addVisitorToHistory(v5);

        // Check if specific visitors are in the ride's history
        System.out.println("\n检查访客是否在乘坐历史记录中：");
        ferrisWheel.checkVisitorFromHistory(v3);
        ferrisWheel.checkVisitorFromHistory(new Visitor("测试", 20, "女", "12345678901", "V006", false, 100.0));

        // Print the number of visitors in the ride's history
        System.out.println("\n乘坐历史记录中的访客数量：");
        ferrisWheel.numberOfVisitors();

        // Print all visitors in the ride's history
        System.out.println("\n打印所有在乘坐历史记录中的访客：");
        ferrisWheel.printRideHistory();
    }

    public void partFourB() {
        // Create a new Ride object named "rollerCoaster"
        // with a maximum capacity of 30, minimum height of 140 cm, and price of 50.0
        Ride rollerCoaster = new Ride("过山车", 30, 140, 50.0);

        // Create at least 5 Visitor objects with different attributes
        Visitor v1 = new Visitor("张三", 25, "男", "13800138000", "V001", false, 200.0);
        Visitor v2 = new Visitor("李四", 30, "女", "13900139000", "V002", true, 300.0);
        Visitor v3 = new Visitor("王五", 22, "男", "13700137000", "V003", false, 150.0);
        Visitor v4 = new Visitor("赵六", 28, "女", "13600136000", "V004", true, 250.0);
        Visitor v5 = new Visitor("钱七", 25, "男", "13500135000", "V005", false, 180.0);

        // Add visitors to the ride's history
        System.out.println("添加访客到乘坐历史记录：");
        rollerCoaster.addVisitorToHistory(v1);
        rollerCoaster.addVisitorToHistory(v2);
        rollerCoaster.addVisitorToHistory(v3);
        rollerCoaster.addVisitorToHistory(v4);
        rollerCoaster.addVisitorToHistory(v5);

        // Print the ride's history before sorting
        System.out.println("\n排序前的乘坐历史记录：");
        rollerCoaster.printRideHistory();

        // Sort the ride's history
        rollerCoaster.sortRideHistory();

        // Print the ride's history after sorting
        System.out.println("\n排序后的乘坐历史记录：");
        rollerCoaster.printRideHistory();
    }

    public void partFive() {
        // Create a new Ride object named "rollerCoaster"
        // Parameters: name of the ride, maximum capacity, minimum height requirement, ticket price, and ride duration
        Ride rollerCoaster = new Ride("过山车", 30, 140, 50.0, 5);

        // Create an Employee object to act as the operator of the ride
        // Parameters: name, age, gender, contact number, employee ID, department, and salary
        Employee operator = new Employee("张经理", 35, "男", "13888888888", "E001", "rides", 5000.0);

        // Assign the operator to the rollerCoaster ride
        rollerCoaster.setOperator(operator);

        // Create and add at least 10 Visitor objects to the ride's queue
        // Each visitor is given a unique name, age, gender, contact number, visitor ID, and funds
        for (int i = 1; i <= 10; i++) {
            Visitor visitor = new Visitor("访客" + i, 20 + i, (i % 2 == 0) ? "女" : "男",
                    "1390000000" + i, "V00" + i, false, 200.0);
            rollerCoaster.addVisitorToQueue(visitor);
        }

        // Print the list of visitors currently in the queue before running the ride
        System.out.println("\n运行周期前的队列：");
        rollerCoaster.printQueue();

        // Run one cycle of the ride, processing visitors according to ride logic
        System.out.println("\n运行一个周期：");
        rollerCoaster.runOneCycle();

        // Print the list of visitors remaining in the queue after running the ride
        System.out.println("\n运行周期后的队列：");
        rollerCoaster.printQueue();

        // Print the ride history, showing all visitors who have completed the ride
        System.out.println("\n乘坐历史记录：");
        rollerCoaster.printRideHistory();
    }

    public void partSix() {
        // Create a new Ride object named "ferrisWheel"
        // Parameters: name of the ride, maximum capacity, minimum height requirement, ticket price, and ride duration
        Ride ferrisWheel = new Ride("摩天轮", 20, 100, 30.0, 4);

        // Create and add at least 5 Visitor objects to the ride's history
        // Each visitor is given a unique name, age, gender, contact number, visitor ID, and funds
        Visitor v1 = new Visitor("张三", 25, "男", "13800138001", "V001", false, 200.0);
        Visitor v2 = new Visitor("李四", 30, "女", "13800138002", "V002", true, 300.0);
        Visitor v3 = new Visitor("王五", 22, "男", "13800138003", "V003", false, 150.0);
        Visitor v4 = new Visitor("赵六", 28, "女", "13800138004", "V004", true, 250.0);
        Visitor v5 = new Visitor("钱七", 35, "男", "13800138005", "V005", false, 180.0);

        // Add each visitor to the ride's historical record
        ferrisWheel.addVisitorToHistory(v1);
        ferrisWheel.addVisitorToHistory(v2);
        ferrisWheel.addVisitorToHistory(v3);
        ferrisWheel.addVisitorToHistory(v4);
        ferrisWheel.addVisitorToHistory(v5);

        // Print the ride history to display all visitors who have taken the ride
        System.out.println("乘坐历史记录：");
        ferrisWheel.printRideHistory();

        // Export the ride history to a CSV file for record-keeping or analysis
        ferrisWheel.exportRideHistory("ferris_wheel_history.csv");
    }

    public void partSeven() {
        // Create a new Ride object named "ferrisWheel"
        // Parameters: name of the ride, maximum capacity, minimum height requirement, ticket price, and ride duration
        Ride ferrisWheel = new Ride("摩天轮", 20, 100, 30.0, 4);

        // Import the ride history from a previously created CSV file
        // This will populate the ride's history with visitor data from the file
        ferrisWheel.importRideHistory("ferris_wheel_history.csv");

        // Print the number of visitors currently in the ride's historical record
        System.out.println("\n乘坐历史记录中的访客数量：");
        System.out.println(ferrisWheel.numberOfVisitors());

        // Print all visitors currently in the ride's historical record
        // This provides a detailed list of all past visitors
        System.out.println("\n乘坐历史记录中的所有访客：");
        ferrisWheel.printRideHistory();
    }
}