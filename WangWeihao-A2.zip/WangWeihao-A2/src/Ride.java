import java.io.*;
import java.util.*;

// Ride class implements the RideInterface to define a theme park ride
public class Ride implements RideInterface {
    // Private fields to store the ride's name, capacity, minimum height requirement, and ticket price
    private String rideName;
    private int capacity;
    private int minHeight;
    private double ticketPrice;

    // Employee object representing the operator of the ride
    private Employee operator;

    // Boolean flag indicating whether the ride is operational
    private boolean isOperational;

    // Queue to manage visitors waiting for the ride
    private Queue<Visitor> visitorQueue;

    // LinkedList to keep a history of visitors who have ridden
    private LinkedList<Visitor> rideHistory;

    // Maximum number of riders allowed per cycle and the number of cycles completed
    private int maxRider;
    private int numOfCycles;

    // Constructor to initialize a Ride object with basic details
    public Ride(String rideName, int capacity, int minHeight, double ticketPrice) {
        this.rideName = rideName; // Set the ride's name
        this.capacity = capacity; // Set the ride's capacity
        this.minHeight = minHeight; // Set the minimum height requirement
        this.ticketPrice = ticketPrice; // Set the ticket price
        this.isOperational = false; // Initially set the ride as not operational
        this.visitorQueue = new LinkedList<>(); // Initialize the visitor queue
        this.rideHistory = new LinkedList<>(); // Initialize the ride history
    }

    // Overloaded constructor to initialize a Ride object with additional maxRider parameter
    public Ride(String rideName, int capacity, int minHeight, double ticketPrice, int maxRider) {
        this.rideName = rideName; // Set the ride's name
        this.capacity = capacity; // Set the ride's capacity
        this.minHeight = minHeight; // Set the minimum height requirement
        this.ticketPrice = ticketPrice; // Set the ticket price
        this.isOperational = false; // Initially set the ride as not operational
        this.visitorQueue = new LinkedList<>(); // Initialize the visitor queue
        this.rideHistory = new LinkedList<>(); // Initialize the ride history
        this.maxRider = maxRider; // Set the maximum number of riders per cycle
        this.numOfCycles = 0; // Initialize the number of cycles to zero
    }

    // Method to add a visitor to the ride's waiting queue
    @Override
    public void addVisitorToQueue(Visitor visitor) {
        visitorQueue.offer(visitor); // Add the visitor to the queue
        System.out.println(visitor.getName() + " successfully joined " + rideName + " waiting queue.");
    }

    // Method to remove a visitor from the ride's waiting queue
    @Override
    public void removeVisitorFromQueue() {
        if (!visitorQueue.isEmpty()) { // Check if the queue is not empty
            Visitor removedVisitor = visitorQueue.poll(); // Remove the visitor from the queue
            System.out.println(removedVisitor.getName() + " has been removed from " + rideName + " waiting queue.");
        } else {
            System.out.println("Removal failed: " + rideName + " waiting queue is already empty.");
        }
    }

    @Override
    public void printQueue() {
        // Print the name of the ride and indicate the start of the waiting queue display
        System.out.println(rideName + " Waiting queue:");

        // Check if the visitor queue is empty
        if (visitorQueue.isEmpty()) {
            // If empty, print a message indicating the queue is empty
            System.out.println("The queue is empty");
        } else {
            // Initialize a position counter for the queue
            int position = 1;
            // Iterate through each visitor in the queue
            for (Visitor visitor : visitorQueue) {
                // Print the visitor's position, name, age, and gender
                System.out.println(position + ". NAME: " + visitor.getName() +
                        ", AGE: " + visitor.getAge() +
                        ", SEX: " + visitor.getGender());
                // Increment the position counter
                position++;
            }
        }
    }

    @Override
    public void runOneCycle() {
        // Check if an operator is assigned to the ride
        if (operator == null) {
            // Print an error message if no operator is assigned
            System.out.println("error：" + rideName + " No operator assigned, unable to run");
            return;
        }
        // Check if the visitor queue is empty
        if (visitorQueue.isEmpty()) {
            // Print an error message if the queue is empty
            System.out.println("error：" + rideName + " The waiting queue is empty and cannot run.");
            return;
        }

        // Determine the number of riders for this cycle
        int ridersThisCycle = Math.min(maxRider, visitorQueue.size());
        // Print a message indicating the ride is starting a cycle with a certain number of riders
        System.out.println(rideName + " Start running a cycle, equipped with " + ridersThisCycle + " tourists.");

        // Loop through the number of riders for this cycle
        for (int i = 0; i < ridersThisCycle; i++) {
            // Remove the visitor from the queue and add to the ride history
            Visitor rider = visitorQueue.poll();
            addVisitorToHistory(rider);
        }

        // Increment the number of cycles completed
        numOfCycles++;
        // Print a message indicating the completion of a cycle
        System.out.println(rideName + " Completed cycle " + numOfCycles + ".");
    }

    @Override
    public void addVisitorToHistory(Visitor visitor) {
        // Add the visitor to the ride history
        rideHistory.add(visitor);
        // Print a message indicating the visitor has been added to the ride history
        System.out.println(visitor.getName() + " added to " + rideName + " ride history records.");
    }

    @Override
    public boolean checkVisitorFromHistory(Visitor visitor) {
        // Check if the visitor is in the ride history
        boolean isInHistory = rideHistory.contains(visitor);
        // Print a message indicating whether the visitor is in the history
        System.out.println(visitor.getName() + (isInHistory ? " is in " : " is not in ") + rideName + " ride history records.");
        // Return the result of the check
        return isInHistory;
    }

    @Override
    public int numberOfVisitors() {
        // Get the total number of visitors in the ride history
        int count = rideHistory.size();
        // Print the total number of visitors in the ride history
        System.out.println(rideName + " has a total of " + count + " visitors in ride history records.");
        // Return the count
        return count;
    }

    @Override
    public void printRideHistory() {
        // Print the ride name and indicate the start of ride history records
        System.out.println(rideName + " Ride history record:");

        // Check if the ride history is empty
        if (rideHistory.isEmpty()) {
            // Print a message indicating no records are available
            System.out.println("No ride records available at the moment");
        } else {
            // Use an iterator to go through the ride history
            Iterator<Visitor> iterator = rideHistory.iterator();
            int count = 1;
            // Iterate over each visitor in the ride history
            while (iterator.hasNext()) {
                Visitor visitor = iterator.next();
                // Print the visitor's details
                System.out.println(count + ". Name: " + visitor.getName() +
                        ", Age: " + visitor.getAge() +
                        ", Sex: " + visitor.getGender());
                // Increment the count
                count++;
            }
        }
    }

    public void sortRideHistory() {
        // Sort the ride history using a custom comparator
        Collections.sort(rideHistory, new VisitorComparator());
        // Print a message indicating the history has been sorted
        System.out.println(rideName + " The ride history has been sorted.");
    }

    public void exportRideHistory(String fileName) {
        // Try to write the ride history to a specified file
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            // Iterate over each visitor in the ride history
            for (Visitor visitor : rideHistory) {
                // Write the visitor's details to the file
                writer.println(visitor.getName() + "," + visitor.getAge() + "," + visitor.getGender() + "," +
                        visitor.getContactNumber() + "," + visitor.getVisitorId() + "," +
                        visitor.hasFastPass() + "," + visitor.getWalletBalance() + "," +
                        visitor.getVisitCount());
            }
            // Print a success message when export is complete
            System.out.println(rideName + " The ride history has been successfully exported to the file: " + fileName);
        } catch (IOException e) {
            // Print an error message if an IOException occurs
            System.err.println("Error exporting " + rideName + " ride history: " + e.getMessage());
        }
    }

    public void importRideHistory(String fileName) {
        // Try to read the ride history from a specified file
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            // Read each line from the file
            while ((line = reader.readLine()) != null) {
                // Split the line into parts using a comma delimiter
                String[] parts = line.split(",");
                // Check if the line has the correct number of parts
                if (parts.length == 8) {
                    // Create a new Visitor object from the parts
                    Visitor visitor = new Visitor(
                            parts[0], Integer.parseInt(parts[1]), parts[2], parts[3],
                            parts[4], Boolean.parseBoolean(parts[5]), Double.parseDouble(parts[6])
                    );
                    visitor.setVisitCount(Integer.parseInt(parts[7]));
                    // Add the visitor to the ride history
                    addVisitorToHistory(visitor);
                }
            }
            // Print a success message when import is complete
            System.out.println(rideName + " The ride history has been successfully imported from the file: " + fileName);
        } catch (IOException e) {
            // Print an error message if an IOException occurs
            System.err.println("Error importing " + rideName + " ride history: " + e.getMessage());
        } catch (NumberFormatException e) {
            // Print an error message if a NumberFormatException occurs
            System.err.println("Data format error during " + rideName + " ride history import: " + e.getMessage());
        }
    }

    // Getter for rideName
    public String getRideName() {
        // Return the name of the ride
        return rideName;
    }

    // Setter for rideName
    public void setRideName(String rideName) {
        // Set the name of the ride
        this.rideName = rideName;
    }

    // Getter for capacity
    public int getCapacity() {
        // Return the capacity of the ride
        return capacity;
    }

    // Setter for capacity
    public void setCapacity(int capacity) {
        // Set the capacity of the ride
        this.capacity = capacity;
    }

    // Getter for minHeight
    public int getMinHeight() {
        // Return the minimum height required for the ride
        return minHeight;
    }

    // Setter for minHeight
    public void setMinHeight(int minHeight) {
        // Set the minimum height required for the ride
        this.minHeight = minHeight;
    }

    // Getter for ticketPrice
    public double getTicketPrice() {
        // Return the ticket price for the ride
        return ticketPrice;
    }

    // Setter for ticketPrice
    public void setTicketPrice(double ticketPrice) {
        // Set the ticket price for the ride
        this.ticketPrice = ticketPrice;
    }

    // Getter for operator
    public Employee getOperator() {
        // Return the operator assigned to the ride
        return operator;
    }

    // Setter for operator
    public void setOperator(Employee operator) {
        // Set the operator for the ride
        this.operator = operator;
        // Set the operational status based on whether an operator is assigned
        this.isOperational = (operator != null);
        // Print a message indicating the operator has been assigned
        System.out.println(operator.getName() + " has been assigned as the operator for " + rideName + ".");
    }

    // Getter for isOperational
    public boolean isOperational() {
        // Return whether the ride is operational
        return isOperational;
    }

    // Setter for isOperational
    public void setOperational(boolean operational) {
        // Set the operational status of the ride
        isOperational = operational;
    }
}