public class Visitor extends Person {
    // Private field to store the visitor's ID
    private String visitorId;
    // Boolean field to indicate if the visitor has a fast pass
    boolean hasFastPass;
    // Private field to store the wallet balance of the visitor
    private double walletBalance;
    // Private field to store the count of visits by the visitor
    private int visitCount;

    // Getter method for the visitorId field
    public String getVisitorId() {
        // Returns the visitor's ID
        return visitorId;
    }

    // Setter method for the visitorId field
    public void setVisitorId(String visitorId) {
        // Sets the visitor's ID to the provided value
        this.visitorId = visitorId;
    }

    // Getter method for the hasFastPass field
    public boolean isHasFastPass() {
        // Returns whether the visitor has a fast pass
        return hasFastPass;
    }

    // Setter method for the hasFastPass field
    public void setHasFastPass(boolean hasFastPass) {
        // Sets whether the visitor has a fast pass
        this.hasFastPass = hasFastPass;
    }

    // Getter method for the walletBalance field
    public double getWalletBalance() {
        // Returns the wallet balance of the visitor
        return walletBalance;
    }

    // Setter method for the walletBalance field
    public void setWalletBalance(double walletBalance) {
        // Sets the wallet balance of the visitor to the provided value
        this.walletBalance = walletBalance;
    }

    // Getter method for the visitCount field
    public int getVisitCount() {
        // Returns the number of visits by the visitor
        return visitCount;
    }

    // Setter method for the visitCount field
    public void setVisitCount(int visitCount) {
        // Sets the number of visits by the visitor to the provided value
        this.visitCount = visitCount;
    }

    // Default constructor for the Visitor class
    public Visitor() {
        // Initializes a new instance of the Visitor class with default values
    }

    // Parameterized constructor for the Visitor class
    public Visitor(String name, int age, String gender, String contactNumber,
                   String visitorId, boolean hasFastPass, double walletBalance) {
        // Calls the constructor of the superclass Person to initialize inherited fields
        super(name, age, gender, contactNumber);
        // Assigns the provided visitor ID to the visitorId field
        this.visitorId = visitorId;
        // Assigns the provided fast pass status to the hasFastPass field
        this.hasFastPass = hasFastPass;
        // Assigns the provided wallet balance to the walletBalance field
        this.walletBalance = walletBalance;
        // Initializes the visit count to 1, indicating the first visit
        this.visitCount = 1;
    }

    // Method to increment the visit count by one
    public void incrementVisitCount() {
        // Increases the visit count by 1
        this.visitCount++;
    }

    // Method to add funds to the visitor's wallet balance
    public void addFunds(double amount) {
        // Increases the wallet balance by the specified amount
        this.walletBalance += amount;
    }

    // Method to spend funds from the visitor's wallet balance
    public boolean spendFunds(double amount) {
        // Checks if the wallet balance is sufficient to cover the amount
        if (this.walletBalance >= amount) {
            // Deducts the amount from the wallet balance
            this.walletBalance -= amount;
            // Returns true indicating the transaction was successful
            return true;
        }
        // Returns false if the wallet balance is insufficient
        return false;
    }

    // Method to check if the visitor has a fast pass
    public boolean hasFastPass() {
        // Returns the fast pass status of the visitor
        return hasFastPass;
    }
}