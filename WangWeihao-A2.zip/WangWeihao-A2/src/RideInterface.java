public interface RideInterface {
    // Adds a visitor to the queue for the ride
    void addVisitorToQueue(Visitor visitor);

    // Removes a visitor from the front of the queue
    void removeVisitorFromQueue();

    // Prints the current queue of visitors waiting for the ride
    void printQueue();

    // Simulates running one cycle of the ride
    void runOneCycle();

    // Adds a visitor to the ride's history
    void addVisitorToHistory(Visitor visitor);

    // Checks if a visitor is in the ride's history
    boolean checkVisitorFromHistory(Visitor visitor);

    // Returns the number of visitors currently in the queue
    int numberOfVisitors();

    // Prints the history of visitors who have taken the ride
    void printRideHistory();
}